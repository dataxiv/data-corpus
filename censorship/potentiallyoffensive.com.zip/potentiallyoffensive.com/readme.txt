

https://potentiallyoffensive.com/lists/bad-word-lists/
