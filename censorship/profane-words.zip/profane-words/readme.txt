# profane-words

- https://github.com/awdev1/better-profane-words
- https://github.com/zautumnz/profane-words
